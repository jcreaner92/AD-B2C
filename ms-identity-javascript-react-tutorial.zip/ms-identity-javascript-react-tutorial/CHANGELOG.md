# CHANGELOG

## 02/08/2021

* Updated msal
* Added smoke tests
* Added GitHub workflows

## 19/02/2021

* Initial sample
